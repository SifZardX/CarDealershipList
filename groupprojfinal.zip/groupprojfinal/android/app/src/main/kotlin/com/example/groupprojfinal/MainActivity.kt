package com.example.groupprojfinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
